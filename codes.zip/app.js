// app.js

const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser'); // For parsing request bodies

const app = express();

// Middleware to parse JSON bodies
app.use(bodyParser.json());

// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/patientDatabase', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

// Define a schema and model for patient records
const recordSchema = new mongoose.Schema({
  name: String,
  age: Number,
  medicalHistory: [String],
});3
const Record = mongoose.model('Record', recordSchema);

// API Endpoints

// GET /records - Retrieve all patient records
app.get('/records', async (req, res) => {
  try {
    const records = await Record.find();
    res.json(records);
  } catch (error) {
    res.status(500).send('Error retrieving records.');
  }
});

// POST /records - Create a new patient record
app.post('/records', async (req, res) => {
  try {
    const newRecord = new Record(req.body);
    await newRecord.save();
    res.status(201).send('Record created successfully.');
  } catch (error) {
    res.status(400).send('Error creating record.');
  }
});

// PUT /records/:id - Update a patient record by ID
app.put('/records/:id', async (req, res) => {
  try {
    const updatedRecord = await Record.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!updatedRecord) {
      return res.status(404).send('Record not found.');
    }
    res.json(updatedRecord);
  } catch (error) {
    res.status(400).send('Error updating record.');
  }
});

// DELETE /records/:id - Delete a patient record by ID
app.delete('/records/:id', async (req, res) => {
  try {
    const deletedRecord = await Record.findByIdAndDelete(req.params.id);
    if (!deletedRecord) {
      return res.status(404).send('Record not found.');
    }
    res.send('Record deleted successfully.');
  } catch (error) {
    res.status(500).send('Error deleting record.');
  }
});

// Start the server
const port = 3000;
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
